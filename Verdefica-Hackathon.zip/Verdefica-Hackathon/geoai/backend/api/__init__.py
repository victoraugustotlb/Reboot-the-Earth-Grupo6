"""GeoAI API."""
